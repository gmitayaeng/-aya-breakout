# Aya Breakout

GitHub Pages: Settings → Pages → Deploy from a branch → main / (root) → Save.
